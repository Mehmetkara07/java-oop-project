
public class plant {
public int plant_id;
public String plant_name;
public int triedness_level;
public plant(int plant_id, String plant_name, int triedness_level) 
{
	this.plant_id = plant_id;
	this.plant_name = plant_name;
	this.triedness_level = triedness_level;
	
}}
