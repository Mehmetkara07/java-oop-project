import java.util.Scanner;

public class javaproject {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		plant Plants[]= new plant[5];
		
		Scanner input = new Scanner(System.in);
		int sizeX=input.nextInt();
		int sizeY=input.nextInt();
		int[][] oldtriednessMap = new int[sizeY][sizeX];
		int triednessMap[][]=new int[sizeY][sizeX];
		int currentYear=0;
		int startXCoord;
		int startYCoord;
		int endXCoord;
		int endYcord;
		int gecici;
		Plants[0]= new plant(1,"artichoke",6);
		Plants[1]= new plant(2,"Tomato",4);
		Plants[2]= new plant(3,"Wheat",2);
		Plants[3]= new plant(4,"artichoke",3);
		Plants[4]= new plant(5,"artichoke",1);
		while(currentYear!=2018) {
			currentYear=input.nextInt();
		
		int plantingCount= input.nextInt();
		
		int type_of_tree[]= new int [plantingCount];
		int addtree;
		for (int i = 0; i <plantingCount ; i++) {
			addtree=input.nextInt();
			type_of_tree[i]= addtree;
		}
			
			for (int i = 0; i < plantingCount; i++) {
				
		
		startXCoord=input.nextInt();
		startYCoord=input.nextInt();
		endXCoord=input.nextInt();
		endYcord=input.nextInt();
		gecici = type_of_tree[i]-1;
		for (int i1 = startYCoord; i1 <= endYcord; i1++) {
			for (int j =startXCoord ; j <=endXCoord ; j++) {
				triednessMap[i1][j] += Plants[gecici].triedness_level;
			}
		}
			}
		for (int  i1= 0;  i1< triednessMap.length; i1++) {
			for (int j = 0; j < triednessMap[0].length; j++) {
				if(oldtriednessMap[i1][j]==triednessMap[i1][j]) {
					triednessMap[i1][j]=triednessMap[i1][j]-3;
					
				}
			}
		}
		for (int  i1= 0;  i1< triednessMap.length; i1++) {
			for (int j = 0; j < triednessMap[0].length; j++) {
				if(triednessMap[i1][j]<0) {
					triednessMap[i1][j]=0;
					
				}
			}
		}
		for (int  i1= 0;  i1< triednessMap.length; i1++) {
			for (int j = 0; j < triednessMap[0].length; j++) {
				oldtriednessMap[i1][j]=triednessMap[i1][j];
					
				
			}
		}

		
				}
		for (int  i= 0;  i< triednessMap.length; i++) {
			for (int j = 0; j < triednessMap[0].length; j++) {
			System.out.print(triednessMap[i][j]+"\t");
					
				
			}
			System.out.println();
		}

}		


		}
		
	




